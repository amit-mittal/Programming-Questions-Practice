import java.io.*;
public class printwriter{
public static void main(String sr[])
{
 PrintWriter  pw=new PrintWriter(System.out,true);
 pw.println("Lavanya");
 int i=9;
//pw.write(i);
 pw.println(i);
 }}

