class Write{
public static void main(String ar[])
{
  char b;
int s=36;
   b='A';
System.out.println(b);
System.out.write(s);
   System.out.write(s);
   }}

