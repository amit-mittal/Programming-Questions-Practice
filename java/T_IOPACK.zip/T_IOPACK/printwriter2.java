import java.io.*;
public class printwriter2{
public static void main(String sr[])
{
 PrintWriter  pw=new PrintWriter(System.out,true);
	 pw.println("Lavanya");
	int i=322;
	pw.write(i);
	char j='p';
	pw.write(j);
	//pw.println("");
	 pw.println(" hhh  " +  i);
 }}

